"""
RibbonWrap v4.1
Generator plugin that wraps a ribbon (or spline) around a target object
by ray-casting a helix onto the target surface.

v1.3 changes:
- Target can now be a hierarchy (null with multiple child meshes): all
  polygon parts are merged for ray-casting. Fixes "nothing generated" on
  multi-part game assets.
- Backface fallback for meshes with flipped normals.
- Normal orientation stabilized (always faces outward).

v1.2 changes:
- Wrap region is now defined by the plugin object itself (position/rotation
  + Length/Radius parameters), like a deformer box. Move/rotate the
  RibbonWrap object to place the wrap.
- Viewport guide: wireframe box + axis line showing the wrap region.
- Helix height is distributed uniformly along the plugin's local wrap axis
  and is never modified by the surface fit (axis-locked, no pitch collapse).
"""

import c4d
import math
from c4d import utils

PLUGIN_ID = 1063321
RW_VERSION = "4.1"

# ---- update check (GitHub) --------------------------------------------
# On C4D startup a background thread fetches UPDATE_URL (version.json) and,
# if a newer version exists, shows a dialog on the main thread offering to
# open the download page. Fails silently (offline / firewall / repo absent).
UPDATE_URL = "https://raw.githubusercontent.com/kslee0350-hub/RibbonWrap/main/version.json"
_update_info = {}


def _ver_tuple(s):
    try:
        return tuple(int(x) for x in str(s).strip().split("."))
    except Exception:
        return (0,)


def _check_update_bg():
    import json
    import urllib.request
    try:
        req = urllib.request.Request(UPDATE_URL, headers={"User-Agent": "RibbonWrap"})
        with urllib.request.urlopen(req, timeout=4) as r:
            data = json.loads(r.read().decode("utf-8"))
        latest = str(data.get("version", ""))
        if _ver_tuple(latest) > _ver_tuple(RW_VERSION):
            _update_info["version"] = latest
            _update_info["url"] = data.get("url", "https://github.com/kslee0350-hub/RibbonWrap")
            _update_info["notes"] = data.get("notes", "")
            print("[RibbonWrap] update available: v%s (current v%s)"
                  % (latest, RW_VERSION))
        else:
            print("[RibbonWrap] up to date (v%s)" % RW_VERSION)
        _update_info["_ok"] = True
    except Exception:
        pass  # no network / repo not set up yet — stay silent
    finally:
        _update_info["_done"] = True


def _show_update_dialog():
    v = _update_info.get("version")
    if not v:
        return
    notes = _update_info.get("notes", "")
    url = _update_info.get("url", "")
    _update_info.clear()   # never show twice
    msg = "RibbonWrap v%s 업데이트가 있습니다. (현재 v%s)" % (v, RW_VERSION)
    if notes:
        msg += "\n\n" + notes
    msg += "\n\n다운로드 페이지를 여시겠습니까?"
    try:
        if c4d.gui.QuestionDialog(msg):
            import webbrowser
            webbrowser.open(url)
    except Exception as e:
        print("[RibbonWrap] update dialog error:", e)


class RibbonWrapCheckCmd(c4d.plugins.CommandData):
    """Extensions menu: manual update check with explicit result dialog."""

    def Execute(self, doc):
        _update_info.clear()
        _check_update_bg()   # synchronous here (main thread, 4 s timeout)
        if _update_info.get("version"):
            _show_update_dialog()
        elif _update_info.get("_ok"):
            c4d.gui.MessageDialog(
                "RibbonWrap v%s — 최신 버전입니다." % RW_VERSION)
        else:
            c4d.gui.MessageDialog(
                "업데이트 확인 실패 (네트워크 또는 저장소 접근 불가).\n"
                "URL: %s" % UPDATE_URL)
        return True


def PluginMessage(id, data):
    """Called by C4D on the main thread. Once startup completes (UI ready),
    wait briefly for the background check, then show the dialog if needed."""
    if id == c4d.C4DPL_PROGRAM_STARTED:
        import time
        for _ in range(45):            # up to ~4.5 s (check timeout is 4 s)
            if _update_info.get("_done"):
                break
            time.sleep(0.1)
        _show_update_dialog()
    return True


# -----------------------------------------------------------------------

# Parameter IDs
RW_TARGET      = 1000
RW_AXIS        = 1001
RW_COILS       = 1002
RW_SEGMENTS    = 1003
RW_OFFSET      = 1004
RW_WIDTH       = 1005
RW_START       = 1006
RW_END         = 1007
RW_OUTPUT      = 1008
RW_FLIP_NORMAL = 1009
RW_SMOOTH_ITER = 1010
RW_LENGTH      = 1014
RW_RADIUS      = 1015
RW_TEXLEN      = 1016
RW_REV_DIR     = 1017
RW_REV_SPIN    = 1018
RW_OUTER       = 1019
RW_TAUT        = 1020
RW_SAG         = 1021
RW_TILT        = 1022
RW_UVROT       = 1023
RW_UVFLIPU     = 1024
RW_UVFLIPV     = 1025
RW_RIBLEN      = 1026
RW_THICK       = 1027
RW_RADIUS2     = 1028
RW_RADSCALE    = 1029
RW_SHAPE       = 1030
RW_SHOWGUIDE   = 1031
RW_AVOID       = 1032
RW_OVERLAP     = 1033
RW_MODE        = 1034
RW_TAPER       = 1035

AXIS_X = 0
AXIS_Y = 1
AXIS_Z = 2

OUT_RIBBON = 0
OUT_SPLINE = 1


def _val(op, pid, default):
    v = op[pid]
    return default if v is None else v


SHAPE_ELLIPSE = 0
SHAPE_CAPSULE = 1

MODE_CYL = 0
MODE_SPH = 1
MODE_CONE = 2


def _capsule_point(ang, a, b):
    """Point + inward normal on a stadium (capsule cross-section) with
    half-extents a (u) and b (v), parametrized by ang 0..2pi walked evenly
    along the perimeter. Returns (x, y, nx, ny)."""
    if abs(a - b) < 1e-6:
        co, si = math.cos(ang), math.sin(ang)
        return a * co, b * si, -co, -si

    if a > b:      # caps left/right, flat top/bottom
        r, s = b, a - b
        P = 2.0 * math.pi * r + 4.0 * s
        p = (ang % (2.0 * math.pi)) / (2.0 * math.pi) * P
        q = math.pi * 0.5 * r          # quarter cap length
        if p < q:                       # right cap, upper quarter
            th = p / r
            return s + r * math.cos(th), r * math.sin(th), -math.cos(th), -math.sin(th)
        p -= q
        if p < 2.0 * s:                 # top wall (right -> left)
            x = s - p
            return x, r, 0.0, -1.0
        p -= 2.0 * s
        if p < 2.0 * q:                 # left cap
            th = math.pi * 0.5 + p / r
            return -s + r * math.cos(th), r * math.sin(th), -math.cos(th), -math.sin(th)
        p -= 2.0 * q
        if p < 2.0 * s:                 # bottom wall (left -> right)
            x = -s + p
            return x, -r, 0.0, 1.0
        p -= 2.0 * s
        th = math.pi * 1.5 + p / r      # right cap, lower quarter
        return s + r * math.cos(th), r * math.sin(th), -math.cos(th), -math.sin(th)
    else:          # caps top/bottom, flat left/right (pill standing up)
        r, s = a, b - a
        P = 2.0 * math.pi * r + 4.0 * s
        p = (ang % (2.0 * math.pi)) / (2.0 * math.pi) * P
        if p < s:                       # right wall up from middle
            return r, p, -1.0, 0.0
        p -= s
        if p < math.pi * r:             # top cap
            th = p / r
            return r * math.cos(th), s + r * math.sin(th), -math.cos(th), -math.sin(th)
        p -= math.pi * r
        if p < 2.0 * s:                 # left wall down
            return -r, s - p, 1.0, 0.0
        p -= 2.0 * s
        if p < math.pi * r:             # bottom cap
            th = math.pi + p / r
            return r * math.cos(th), -s + r * math.sin(th), -math.cos(th), -math.sin(th)
        p -= math.pi * r
        return r, -s + p, -1.0, 0.0     # right wall up to middle


def _uv_xform(u, v, rot, fu, fv):
    """Apply flips then 0/90/180/270 rotation to a UV pair."""
    if fu:
        u = 1.0 - u
    if fv:
        v = 1.0 - v
    if rot == 1:      # 90
        u, v = v, 1.0 - u
    elif rot == 2:    # 180
        u, v = 1.0 - u, 1.0 - v
    elif rot == 3:    # 270
        u, v = 1.0 - v, u
    return u, v


def _normalized_mg(mg):
    """Strip scale from a matrix; return (unit-axis matrix, per-axis scales)."""
    sx = mg.v1.GetLength()
    sy = mg.v2.GetLength()
    sz = mg.v3.GetLength()
    n = c4d.Matrix(mg.off,
                   mg.v1 / (sx or 1.0),
                   mg.v2 / (sy or 1.0),
                   mg.v3 / (sz or 1.0))
    return n, sx, sy, sz


def _axis_scales(axis, sx, sy, sz):
    """(axial scale, u scale, v scale) for the chosen wrap axis."""
    if axis == AXIS_X:
        return sx, sy, sz
    if axis == AXIS_Y:
        return sy, sz, sx
    return sz, sx, sy


def _axis_basis(axis):
    """(u, v, w): w = wrap axis, u/v span the radial plane (all local)."""
    if axis == AXIS_X:
        w = c4d.Vector(1, 0, 0); u = c4d.Vector(0, 1, 0); v = c4d.Vector(0, 0, 1)
    elif axis == AXIS_Y:
        w = c4d.Vector(0, 1, 0); u = c4d.Vector(0, 0, 1); v = c4d.Vector(1, 0, 0)
    else:
        w = c4d.Vector(0, 0, 1); u = c4d.Vector(1, 0, 0); v = c4d.Vector(0, 1, 0)
    return u, v, w


def _collect_polys(obj, out):
    """Recursively collect every polygon cache in the hierarchy with its
    global matrix. Standard cache-traversal pattern."""
    if obj is None:
        return
    tmp = obj.GetDeformCache()
    if tmp is not None:
        _collect_polys(tmp, out)
    else:
        tmp = obj.GetCache()
        if tmp is not None:
            _collect_polys(tmp, out)
        elif not obj.GetBit(c4d.BIT_CONTROLOBJECT) and obj.CheckType(c4d.Opolygon):
            if obj.GetPolygonCount() > 0:
                out.append((obj, obj.GetMg()))
    child = obj.GetDown()
    while child:
        _collect_polys(child, out)
        child = child.GetNext()


def _hier_key_rel(roots, ref_inv):
    """Change-detection key for hierarchies, RELATIVE to a reference frame:
    local dirty counters plus a hash of every node's matrix expressed in the
    reference space. Invariant under rigid motion of the whole group, so
    moving target + ribbons together triggers no recompute."""
    tsum = 0
    msum = 0.0
    stack = [r for r in roots if r is not None]
    while stack:
        n = stack.pop()
        tsum += n.GetDirty(c4d.DIRTYFLAGS_DATA
                           | c4d.DIRTYFLAGS_MATRIX
                           | c4d.DIRTYFLAGS_CACHE)
        mg = ref_inv * n.GetMg()
        msum += (mg.off.x + mg.off.y * 3.0 + mg.off.z * 7.0
                 + mg.v1.x * 11.0 + mg.v1.y + mg.v2.y * 13.0
                 + mg.v2.z + mg.v3.z * 17.0 + mg.v3.x)
        child = n.GetDown()
        while child:
            stack.append(child)
            child = child.GetNext()
    return (tsum, round(msum, 3))


def _mat_key(m):
    return (round(m.off.x, 3), round(m.off.y, 3), round(m.off.z, 3),
            round(m.v1.x, 4), round(m.v1.y, 4), round(m.v1.z, 4),
            round(m.v2.x, 4), round(m.v2.y, 4), round(m.v2.z, 4),
            round(m.v3.x, 4), round(m.v3.y, 4), round(m.v3.z, 4))


def _gather_avoid_roots(op, doc, target):
    """Wrap Over Objects list entries."""
    roots = []
    ex = op[RW_AVOID]
    if ex is not None and doc is not None:
        try:
            for i in range(ex.GetObjectCount()):
                o = ex.ObjectFromIndex(doc, i)
                if o is not None and o is not op and o is not target \
                        and o not in roots:
                    roots.append(o)
        except Exception:
            pass
    return roots


def _build_merged(roots, ref_inv):
    """Merge every polygon under the given root objects into ONE polygon
    object in the given REFERENCE space (typically target-local, so the
    cache survives any rigid motion of the whole group)."""
    found = []
    for root in roots:
        if root is None:
            continue
        before = len(found)
        _collect_polys(root, found)
        if len(found) == before and root.CheckType(c4d.Opolygon) \
                and root.GetPolygonCount() > 0:
            found.append((root, root.GetMg()))
    if not found:
        return None

    total_pts = sum(p.GetPointCount() for p, _ in found)
    total_pgs = sum(p.GetPolygonCount() for p, _ in found)
    if total_pts == 0 or total_pgs == 0:
        return None

    merged = c4d.PolygonObject(total_pts, total_pgs)
    poff = 0
    goff = 0
    for poly, mg in found:
        conv = ref_inv * mg
        pts = poly.GetAllPoints()
        for i, p in enumerate(pts):
            merged.SetPoint(poff + i, conv * p)
        for i in range(poly.GetPolygonCount()):
            cp = poly.GetPolygon(i)
            merged.SetPolygon(goff + i, c4d.CPolygon(
                cp.a + poff, cp.b + poff, cp.c + poff, cp.d + poff))
        poff += len(pts)
        goff += poly.GetPolygonCount()
    merged.Message(c4d.MSG_UPDATE)
    return merged


class RibbonWrapData(c4d.plugins.ObjectData):

    def Init(self, node, isCloneInit=False):
        self.InitAttr(node, int,   [RW_AXIS])
        self.InitAttr(node, float, [RW_COILS])
        self.InitAttr(node, int,   [RW_SEGMENTS])
        self.InitAttr(node, float, [RW_OFFSET])
        self.InitAttr(node, float, [RW_WIDTH])
        self.InitAttr(node, float, [RW_START])
        self.InitAttr(node, float, [RW_END])
        self.InitAttr(node, int,   [RW_OUTPUT])
        self.InitAttr(node, bool,  [RW_FLIP_NORMAL])
        self.InitAttr(node, int,   [RW_SMOOTH_ITER])
        self.InitAttr(node, float, [RW_LENGTH])
        self.InitAttr(node, float, [RW_RADIUS])
        self.InitAttr(node, float, [RW_TEXLEN])
        self.InitAttr(node, bool,  [RW_REV_DIR])
        self.InitAttr(node, bool,  [RW_REV_SPIN])
        self.InitAttr(node, bool,  [RW_OUTER])
        self.InitAttr(node, int,   [RW_TAUT])
        self.InitAttr(node, float, [RW_SAG])
        self.InitAttr(node, float, [RW_TILT])
        self.InitAttr(node, int,   [RW_UVROT])
        self.InitAttr(node, bool,  [RW_UVFLIPU])
        self.InitAttr(node, bool,  [RW_UVFLIPV])
        self.InitAttr(node, float, [RW_RIBLEN])
        self.InitAttr(node, float, [RW_THICK])
        self.InitAttr(node, float, [RW_RADIUS2])
        self.InitAttr(node, float, [RW_RADSCALE])
        self.InitAttr(node, int,   [RW_SHAPE])
        self.InitAttr(node, bool,  [RW_SHOWGUIDE])
        self.InitAttr(node, bool,  [RW_OVERLAP])
        self.InitAttr(node, int,   [RW_MODE])
        self.InitAttr(node, float, [RW_TAPER])

        node[RW_AXIS] = AXIS_Z
        node[RW_COILS] = 6.0
        node[RW_SEGMENTS] = 48
        node[RW_OFFSET] = 0.5
        node[RW_WIDTH] = 10.0
        node[RW_START] = 0.0
        node[RW_END] = 1.0
        node[RW_OUTPUT] = OUT_RIBBON
        node[RW_FLIP_NORMAL] = False
        node[RW_SMOOTH_ITER] = 2
        node[RW_LENGTH] = 200.0
        node[RW_RADIUS] = 100.0
        node[RW_TEXLEN] = 50.0
        node[RW_REV_DIR] = False
        node[RW_REV_SPIN] = False
        node[RW_OUTER] = True
        node[RW_TAUT] = 80
        node[RW_SAG] = 2.0
        node[RW_TILT] = 0.0
        node[RW_UVROT] = 0
        node[RW_UVFLIPU] = False
        node[RW_UVFLIPV] = False
        node[RW_RIBLEN] = 0.0
        node[RW_THICK] = 1.0
        node[RW_RADIUS2] = 100.0
        node[RW_RADSCALE] = 1.0
        node[RW_SHAPE] = 0
        node[RW_SHOWGUIDE] = True
        node[RW_OVERLAP] = True
        node[RW_MODE] = 0
        node[RW_TAPER] = 0.0
        return True

    def Message(self, node, type, data):
        # bake any object scale into Length/Radius and reset scale to 1 so
        # scaling the box only ever affects those two parameters
        if type in (c4d.MSG_UPDATE, c4d.MSG_CHANGE):
            ml = node.GetMl()
            sx = ml.v1.GetLength()
            sy = ml.v2.GetLength()
            sz = ml.v3.GetLength()
            if (abs(sx - 1.0) > 1e-6 or abs(sy - 1.0) > 1e-6
                    or abs(sz - 1.0) > 1e-6):
                axis = _val(node, RW_AXIS, AXIS_Z)
                s_ax, s_u, s_v = _axis_scales(axis, sx, sy, sz)
                node[RW_LENGTH] = _val(node, RW_LENGTH, 200.0) * s_ax
                ru = _val(node, RW_RADIUS, 100.0)
                rv = _val(node, RW_RADIUS2, ru)
                node[RW_RADIUS] = ru * s_u
                node[RW_RADIUS2] = rv * s_v
                ml = c4d.Matrix(ml.off,
                                ml.v1 / (sx or 1.0),
                                ml.v2 / (sy or 1.0),
                                ml.v3 / (sz or 1.0))
                node.SetMl(ml)
        return True

    def CheckDirty(self, op, doc):
        mg = op.GetMg()
        key = (round(mg.v1.GetLength(), 6),
               round(mg.v2.GetLength(), 6),
               round(mg.v3.GetLength(), 6))
        if getattr(self, "_last_scale", None) != key:
            self._last_scale = key
            op.SetDirty(c4d.DIRTYFLAGS_DATA)

        # watch target internals + relative layout (target <-> ribbon <->
        # wrap-over objects). Keys are target-relative, so moving the whole
        # group (null with target + ribbons) changes nothing and costs
        # nothing; only relative motion triggers a recompute.
        target = op[RW_TARGET]
        if target is not None:
            ref_inv = ~target.GetMg()
            avoid = _gather_avoid_roots(op, doc, target)
            wkey = (_hier_key_rel([target], ref_inv),
                    _hier_key_rel(avoid, ref_inv),
                    _mat_key(ref_inv * op.GetMg()))
            if getattr(self, "_last_wkey", None) != wkey:
                self._last_wkey = wkey
                op.SetDirty(c4d.DIRTYFLAGS_DATA)

    # ------------------------------------------------------------- handles

    def GetHandleCount(self, op):
        return 3

    def GetHandle(self, op, i, info):
        axis = _val(op, RW_AXIS, AXIS_Z)
        u, v, w = _axis_basis(axis)
        if i == 0:   # length handle on +axis face
            info.position = w * (_val(op, RW_LENGTH, 200.0) * 0.5)
            info.direction = w
        elif i == 1:  # horizontal radius handle
            rs = max(0.01, _val(op, RW_RADSCALE, 1.0))
            info.position = u * (_val(op, RW_RADIUS, 100.0) * rs)
            info.direction = u
        else:         # vertical radius handle
            rs = max(0.01, _val(op, RW_RADSCALE, 1.0))
            rv = _val(op, RW_RADIUS2, None)
            if rv is None:
                rv = _val(op, RW_RADIUS, 100.0)
            info.position = v * (rv * rs)
            info.direction = v
        info.type = c4d.HANDLECONSTRAINTTYPE_LINEAR

    def SetHandle(self, op, i, p, info):
        val = p.Dot(info.direction)
        if i == 0:
            op[RW_LENGTH] = max(0.001, val * 2.0)
        elif i == 1:
            rs = max(0.01, _val(op, RW_RADSCALE, 1.0))
            op[RW_RADIUS] = max(0.001, val / rs)
        else:
            rs = max(0.01, _val(op, RW_RADSCALE, 1.0))
            op[RW_RADIUS2] = max(0.001, val / rs)

    # ------------------------------------------------------------ viewport

    def Draw(self, op, drawpass, bd, bh):
        if drawpass == c4d.DRAWPASS_HANDLES:
            try:
                bd.SetMatrix_Matrix(op, bh.GetMg())
                hcol = c4d.GetViewColor(c4d.VIEWCOLOR_ACTIVEPOINT)
                info = c4d.HandleInfo()
                try:
                    bd.SetPointSize(10.0)
                except Exception:
                    pass
                for i in range(self.GetHandleCount(op)):
                    self.GetHandle(op, i, info)
                    bd.SetPen(hcol)
                    try:
                        bd.DrawHandle(info.position, c4d.DRAWHANDLE_CUSTOM, 0)
                    except Exception:
                        bd.DrawHandle(info.position, c4d.DRAWHANDLE_BIG, 0)
                    bd.DrawLine(c4d.Vector(0), info.position, 0)
            except Exception as e:
                if not getattr(self, "_handle_err", False):
                    self._handle_err = True
                    print("[RibbonWrap] handle draw error:", e)
            return c4d.DRAWRESULT_OK
        if drawpass != c4d.DRAWPASS_OBJECT:
            return c4d.DRAWRESULT_SKIP
        if not _val(op, RW_SHOWGUIDE, True):
            return c4d.DRAWRESULT_OK

        axis   = _val(op, RW_AXIS, AXIS_Z)
        length = _val(op, RW_LENGTH, 200.0)
        rscale = max(0.01, _val(op, RW_RADSCALE, 1.0))
        rad_u  = _val(op, RW_RADIUS, 100.0) * rscale
        rad_v  = _val(op, RW_RADIUS2, None)
        rad_v  = (rad_u if rad_v is None else rad_v * rscale)
        u, v, w = _axis_basis(axis)
        hl = length * 0.5

        bd.SetMatrix_Matrix(op, bh.GetMg())
        bd.SetPen(c4d.Vector(1.0, 0.6, 0.2))  # orange guide

        # wireframe box: radial extent = radius, axial extent = length
        corners = []
        for sa in (-1, 1):          # along axis
            for su in (-1, 1):      # radial u
                for sv in (-1, 1):  # radial v
                    corners.append(w * (hl * sa) + u * (rad_u * su) + v * (rad_v * sv))

        def L(i, j):
            bd.DrawLine(corners[i], corners[j], 0)

        # indices: sa*4 + su*2 + sv  with (-1->0, 1->1)
        # 0:(-,-,-) 1:(-,-,+) 2:(-,+,-) 3:(-,+,+) 4:(+,-,-) 5:(+,-,+) 6:(+,+,-) 7:(+,+,+)
        L(0, 1); L(1, 3); L(3, 2); L(2, 0)   # bottom ring
        L(4, 5); L(5, 7); L(7, 6); L(6, 4)   # top ring
        L(0, 4); L(1, 5); L(2, 6); L(3, 7)   # verticals

        # cross-section outline at both ends (cone mode tapers the far end)
        shape = _val(op, RW_SHAPE, SHAPE_ELLIPSE)
        mode_d = _val(op, RW_MODE, MODE_CYL)
        fa = fb = 1.0
        if mode_d == MODE_CONE:
            tp = max(0.02, _val(op, RW_TAPER, 0.0))
            if _val(op, RW_REV_DIR, False):
                fb = tp        # travel ends at -axis
            else:
                fa = tp        # travel ends at +axis
        bd.SetPen(c4d.Vector(1.0, 0.75, 0.35))
        segs_c = 40
        prev_a = prev_b = None
        for k in range(segs_c + 1):
            ang = 2.0 * math.pi * k / segs_c
            if shape == SHAPE_CAPSULE:
                xa, ya, _, _ = _capsule_point(ang, rad_u * fa, rad_v * fa)
                xb, yb, _, _ = _capsule_point(ang, rad_u * fb, rad_v * fb)
            else:
                xa, ya = rad_u * fa * math.cos(ang), rad_v * fa * math.sin(ang)
                xb, yb = rad_u * fb * math.cos(ang), rad_v * fb * math.sin(ang)
            cur_a = u * xa + v * ya
            cur_b = u * xb + v * yb
            if prev_a is not None:
                bd.DrawLine(w * hl + prev_a, w * hl + cur_a, 0)
                bd.DrawLine(w * -hl + prev_b, w * -hl + cur_b, 0)
            prev_a, prev_b = cur_a, cur_b

        # spherical mode: meridian outline (u-w plane)
        if _val(op, RW_MODE, MODE_CYL) == MODE_SPH:
            prev = None
            for k in range(segs_c + 1):
                th = 2.0 * math.pi * k / segs_c
                cur = u * (rad_u * math.cos(th)) + w * (hl * math.sin(th))
                if prev is not None:
                    bd.DrawLine(prev, cur, 0)
                prev = cur

        # axis line
        bd.SetPen(c4d.Vector(0.3, 0.8, 1.0))
        bd.DrawLine(w * -hl, w * hl, 0)

        return c4d.DRAWRESULT_OK

    # ---------------------------------------------------------------- core

    def _sample_wrap(self, op, colliders, mg_n, tmg):
        """Ray-cast helix samples onto target-local-space colliders.
        Region = plugin's own box. Returns list of (pos, normal) in the
        generator's (unit-scale) local space."""
        axis   = _val(op, RW_AXIS, AXIS_Z)
        coils  = max(0.01, _val(op, RW_COILS, 6.0))
        segs   = max(8, _val(op, RW_SEGMENTS, 48))
        offset = _val(op, RW_OFFSET, 0.5)
        s0     = _val(op, RW_START, 0.0)
        s1     = _val(op, RW_END, 1.0)
        start  = min(s0, s1)
        end    = max(s0, s1)
        flip   = _val(op, RW_FLIP_NORMAL, False)
        mg = op.GetMg()
        _, sx, sy, sz = _normalized_mg(mg)
        s_ax, s_u, s_v = _axis_scales(_val(op, RW_AXIS, AXIS_Z), sx, sy, sz)
        length = max(0.001, _val(op, RW_LENGTH, 200.0) * s_ax)
        ru_p = _val(op, RW_RADIUS, 100.0)
        rv_p = _val(op, RW_RADIUS2, None)
        if rv_p is None:
            rv_p = ru_p
        rscale = max(0.01, _val(op, RW_RADSCALE, 1.0))
        rad_u = max(0.001, ru_p * s_u * rscale)
        rad_v = max(0.001, rv_p * s_v * rscale)
        tilt = _val(op, RW_TILT, 0.0)   # radians (UNIT DEGREE in UI)
        rev_d  = _val(op, RW_REV_DIR, False)
        rev_s  = _val(op, RW_REV_SPIN, False)

        u, v, w = _axis_basis(axis)
        hl = length * 0.5

        conv_l2t = (~tmg) * mg_n        # generator-local -> target-local
        conv_t2l = (~mg_n) * tmg        # target-local -> generator-local
        ray_s = conv_l2t.MulV(c4d.Vector(1, 0, 0)).GetLength() or 1.0

        total = int(segs * coils)
        if total < 2:
            return None

        outer = _val(op, RW_OUTER, True)
        taut  = max(0, _val(op, RW_TAUT, 80))
        shape = _val(op, RW_SHAPE, SHAPE_ELLIPSE)
        mode  = _val(op, RW_MODE, MODE_CYL)
        if mode == MODE_SPH:
            tilt = 0.0   # coil tilt is a cylindrical concept
        taper = max(0.0, _val(op, RW_TAPER, 0.0))
        cone_m = 0.0
        w_t = w
        if mode == MODE_CONE:
            if rev_d:
                w_t = -w
            avg_r = (rad_u + rad_v) * 0.5
            cone_m = avg_r * (1.0 - taper) / length   # radial slope dr/dh

        # pass 1: cast all rays, record hit distance along the ray or None
        entries = []   # (h, o_l, d_l, ang, dist or None, normal or None)
        maxdist = 4.0 * max(rad_u, rad_v)
        for i in range(total + 1):
            t = i / float(total)
            if t < start or t > end:
                continue
            ang = t * coils * 2.0 * math.pi
            if rev_s:
                ang = -ang                             # CW <-> CCW
            h = -hl + length * t                       # LOCKED axial position
            if rev_d:
                h = -h                                 # +axis <-> -axis travel

            if mode == MODE_SPH:
                # spherical spiral: uniform polar-angle steps pole to pole,
                # rays aimed at the box center — natural wrap on ball-like
                # targets (no cylindrical projection artifacts at the poles)
                th = math.pi * t
                if rev_d:
                    th = math.pi - th
                st = math.sin(th)
                o_l = (w * (hl * math.cos(th))
                       + u * (math.cos(ang) * rad_u * st)
                       + v * (math.sin(ang) * rad_v * st))
                ol_len = o_l.GetLength()
                if ol_len < 1e-6:
                    continue
                d_l = -(o_l / ol_len)                  # toward center
            else:
                f = 1.0
                if mode == MODE_CONE:
                    f = max(0.02, 1.0 + (taper - 1.0) * t)   # taper along travel
                ru_f, rv_f = rad_u * f, rad_v * f
                if shape == SHAPE_CAPSULE:
                    x, y, nx, ny = _capsule_point(ang, ru_f, rv_f)
                    o_l = w * h + u * x + v * y
                    d_l = u * nx + v * ny              # inward boundary normal
                else:
                    co, si = math.cos(ang), math.sin(ang)
                    roff = u * (co * ru_f) + v * (si * rv_f)
                    o_l = w * h + roff
                    d_l = -(roff / roff.GetLength())   # toward the axis
                if mode == MODE_CONE and abs(cone_m) > 1e-6:
                    # tilt the ray to the cone surface normal so the ribbon
                    # face follows the slanted surface (also on bridged spans)
                    d_l = d_l - w_t * cone_m
                    d_l.Normalize()

            md = o_l.GetLength() * 2.0 if mode == MODE_SPH else maxdist
            p0 = conv_l2t * o_l                        # to target-local
            d  = conv_l2t.MulV(d_l)
            d.Normalize()

            dist = None
            n_hit = None
            best = None
            best_any = None
            for rc in colliders:
                if not rc.Intersect(p0, d, md * ray_s):
                    continue
                for k in range(rc.GetIntersectionCount()):
                    hit = rc.GetIntersection(k)
                    if best_any is None or hit["distance"] < best_any["distance"]:
                        best_any = hit
                    if hit["backface"]:
                        continue
                    if best is None or hit["distance"] < best["distance"]:
                        best = hit
            if best is None:
                best = best_any
            if best is not None:
                hp_l = conv_t2l * best["hitpos"]       # back to generator-local
                dist = (hp_l - o_l).Dot(d_l)           # metric-safe distance
                n_hit = conv_t2l.MulV(best["f_normal"])
                n_hit.Normalize()
                if n_hit.Dot(d_l) > 0:                 # face against the ray
                    n_hit = -n_hit
            entries.append((h, o_l, d_l, ang, dist, n_hit))

        if len(entries) < 2:
            return None

        dists = [e[4] for e in entries]
        valid_idx = [i for i, r in enumerate(dists) if r is not None]
        if len(valid_idx) < 2:
            return None

        # fill misses (gaps in the object) by linear interpolation between
        # neighbouring contact points; ends clamp to nearest valid
        first_v, last_v = valid_idx[0], valid_idx[-1]
        for i in range(len(dists)):
            if dists[i] is not None:
                continue
            if i < first_v:
                dists[i] = dists[first_v]
            elif i > last_v:
                dists[i] = dists[last_v]
            else:
                a = max(j for j in valid_idx if j < i)
                b = min(j for j in valid_idx if j > i)
                f = (i - a) / float(b - a)
                dists[i] = dists[a] * (1.0 - f) + dists[b] * f

        # taut band in hit-distance space: smaller distance = further out, so
        # the no-dip envelope pulls distances DOWN to bridge holes/recesses,
        # then Sag lets the band sink back toward the surface
        if outer and taut > 0:
            sag = max(0.0, _val(op, RW_SAG, 2.0))
            raw = list(dists)
            for _ in range(taut):
                changed = False
                for j in range(1, len(dists) - 1):
                    m = (dists[j - 1] + dists[j + 1]) * 0.5
                    if dists[j] > m + 1e-5:
                        dists[j] = m
                        changed = True
                if not changed:
                    break
            if sag > 0.0:
                for j in range(len(dists)):
                    dists[j] = min(raw[j], dists[j] + sag)

        tan_tilt = math.tan(tilt) if abs(tilt) > 1e-6 else 0.0
        samples = []
        for (h, o_l, d_l, ang, rawd, n_hit), dist in zip(entries, dists):
            lifted = (rawd is None) or (rawd - dist > 0.01)
            if lifted or n_hit is None:
                n_l = -d_l                    # bridged span: outward along ray
            else:
                n_l = n_hit
            if flip:
                n_l = -n_l
            p = o_l + d_l * (dist - offset)
            if tan_tilt:
                rlen = (p - w * p.Dot(w)).GetLength()
                p = p + w * (rlen * tan_tilt * math.cos(ang))
            samples.append((p, n_l))

        if len(samples) < 2:
            return None

        lock_axis = (mode != MODE_SPH)
        it = max(0, _val(op, RW_SMOOTH_ITER, 2))
        for _ in range(it):
            new = [samples[0]]
            for j in range(1, len(samples) - 1):
                p = (samples[j - 1][0] + samples[j][0] * 2.0 + samples[j + 1][0]) * 0.25
                n = (samples[j - 1][1] + samples[j][1] * 2.0 + samples[j + 1][1]) * 0.25
                n.Normalize()
                if lock_axis:
                    # keep axial coordinate locked through smoothing as well
                    h = samples[j][0].Dot(w)
                    p = p - w * p.Dot(w) + w * h
                new.append((p, n))
            new.append(samples[-1])
            samples = new

        return samples

    def _build_spline(self, samples):
        n = len(samples)
        spl = c4d.SplineObject(n, c4d.SPLINETYPE_BSPLINE)
        for i, (p, _) in enumerate(samples):
            spl.SetPoint(i, p)
        spl.Message(c4d.MSG_UPDATE)
        return spl

    def _build_ribbon(self, samples, width, tex_len, uv_opts=(0, False, False, 0.0),
                      thickness=0.0, bank=None):
        n = len(samples)
        half = width * 0.5

        # cumulative arc length for real-scale U coordinate
        arc = [0.0] * n
        for i in range(1, n):
            arc[i] = arc[i - 1] + (samples[i][0] - samples[i - 1][0]).GetLength()

        # per-sample frame: side vector + normal (with optional overlap bank)
        sides = []
        lifts = []
        for i, (p, nrm) in enumerate(samples):
            if i == 0:
                tan = samples[1][0] - samples[0][0]
            elif i == n - 1:
                tan = samples[-1][0] - samples[-2][0]
            else:
                tan = samples[i + 1][0] - samples[i - 1][0]
            tan.Normalize()
            side = tan.Cross(nrm)
            side.Normalize()
            lift = c4d.Vector(0)
            if bank is not None:
                w_dir, sinb = bank
                if side.Dot(w_dir) < 0:      # side must point along travel
                    side = -side
                cosb = math.sqrt(max(0.0, 1.0 - sinb * sinb))
                # tilt strip around its tangent: leading edge (+side) pivots
                # on the surface, trailing edge (-side) rises by width*sinb
                # (= thickness), riding onto the previous coil
                side = side * cosb - nrm * sinb
                lift = nrm * (width * 0.5 * sinb)
            sides.append(side)
            lifts.append(lift)

        rot, fu, fv, riblen = uv_opts
        if riblen > 0.001:
            denom = max(arc[-1], 1e-6)
            def U(a):
                return a / denom
        else:
            tl = tex_len if tex_len > 0.0001 else max(0.001, width) * 5.0
            def U(a):
                return a / tl

        def uvq(i, va, vb):
            """UV quad for segment i spanning V va..vb (after xform)."""
            u0, u1 = U(arc[i]), U(arc[i + 1])
            a = _uv_xform(u0, vb, rot, fu, fv)
            b = _uv_xform(u0, va, rot, fu, fv)
            c = _uv_xform(u1, va, rot, fu, fv)
            d = _uv_xform(u1, vb, rot, fu, fv)
            return (c4d.Vector(a[0], a[1], 0), c4d.Vector(b[0], b[1], 0),
                    c4d.Vector(c[0], c[1], 0), c4d.Vector(d[0], d[1], 0))

        flat = thickness <= 0.0001

        if flat:
            poly = c4d.PolygonObject(n * 2, (n - 1))
            for i, (p, nrm) in enumerate(samples):
                base = p + lifts[i]
                poly.SetPoint(i * 2,     base - sides[i] * half)
                poly.SetPoint(i * 2 + 1, base + sides[i] * half)
            uvw = c4d.UVWTag(n - 1)
            for i in range(n - 1):
                a = i * 2
                poly.SetPolygon(i, c4d.CPolygon(a, a + 1, a + 3, a + 2))
                qa, qb, qc, qd = uvq(i, 0.0, 1.0)
                uvw.SetSlow(i, qa, qb, qc, qd)
            poly.Message(c4d.MSG_UPDATE)
            poly.InsertTag(uvw)
        else:
            # solid ribbon: bottom layer at sample position, top layer raised
            # along the normal by `thickness`
            npts = n * 4                    # bottom L/R + top L/R
            segs = n - 1
            npoly = segs * 4 + 2            # top, bottom, 2 sides, 2 caps
            poly = c4d.PolygonObject(npts, npoly)
            B = 0        # bottom layer base index
            T = n * 2    # top layer base index
            for i, (p, nrm) in enumerate(samples):
                tlift = nrm * thickness
                base = p + lifts[i]
                poly.SetPoint(B + i * 2,     base - sides[i] * half)
                poly.SetPoint(B + i * 2 + 1, base + sides[i] * half)
                poly.SetPoint(T + i * 2,     base - sides[i] * half + tlift)
                poly.SetPoint(T + i * 2 + 1, base + sides[i] * half + tlift)

            uvw = c4d.UVWTag(npoly)
            pi = 0
            for i in range(segs):
                a = i * 2
                # top face (faces outward along +normal)
                poly.SetPolygon(pi, c4d.CPolygon(T + a, T + a + 1, T + a + 3, T + a + 2))
                qa, qb, qc, qd = uvq(i, 0.0, 1.0)
                uvw.SetSlow(pi, qa, qb, qc, qd)
                pi += 1
                # bottom face (reversed winding)
                poly.SetPolygon(pi, c4d.CPolygon(B + a + 2, B + a + 3, B + a + 1, B + a))
                uvw.SetSlow(pi, qd, qc, qb, qa)
                pi += 1
                # left wall
                poly.SetPolygon(pi, c4d.CPolygon(B + a, B + a + 2, T + a + 2, T + a))
                qa, qb, qc, qd = uvq(i, 0.0, 0.02)
                uvw.SetSlow(pi, qa, qb, qc, qd)
                pi += 1
                # right wall
                poly.SetPolygon(pi, c4d.CPolygon(B + a + 3, B + a + 1, T + a + 1, T + a + 3))
                qa, qb, qc, qd = uvq(i, 0.98, 1.0)
                uvw.SetSlow(pi, qa, qb, qc, qd)
                pi += 1
            # start cap
            poly.SetPolygon(pi, c4d.CPolygon(B + 0, B + 1, T + 1, T + 0))
            z = c4d.Vector(0)
            uvw.SetSlow(pi, z, z, z, z)
            pi += 1
            # end cap
            e = (n - 1) * 2
            poly.SetPolygon(pi, c4d.CPolygon(B + e + 1, B + e, T + e, T + e + 1))
            uvw.SetSlow(pi, z, z, z, z)

            poly.Message(c4d.MSG_UPDATE)
            poly.InsertTag(uvw)

        tag = c4d.BaseTag(c4d.Tphong)
        tag[c4d.PHONGTAG_PHONG_ANGLELIMIT] = True
        tag[c4d.PHONGTAG_PHONG_ANGLE] = utils.DegToRad(60.0)
        poly.InsertTag(tag)
        return poly

    # ------------------------------------------------------------- generator

    def GetVirtualObjects(self, op, hh):
        target = op[RW_TARGET]
        if target is None:
            return c4d.BaseObject(c4d.Onull)

        # collect "wrap over" objects (children + list)
        doc = op.GetDocument()
        avoid_roots = _gather_avoid_roots(op, doc, target)

        # target-relative change keys (invariant under group rigid motion)
        tmg = target.GetMg()
        ref_inv = ~tmg
        tkey = _hier_key_rel([target], ref_inv)
        akey = _hier_key_rel(avoid_roots, ref_inv)
        okey = _mat_key(ref_inv * op.GetMg())

        dirty = op.CheckCache(hh) or op.IsDirty(c4d.DIRTYFLAGS_DATA)
        if getattr(self, "_last_wkeys", None) != (tkey, akey, okey):
            self._last_wkeys = (tkey, akey, okey)
            dirty = True

        if not dirty:
            cache = op.GetCache(hh)
            if cache is not None:
                return cache

        # target collider in TARGET-LOCAL space (cached; heavy geometry
        # rebuilt only when the target hierarchy itself changes internally)
        t_ck = (target.GetGUID(), tkey)
        if getattr(self, "_rc_t", None) is None or getattr(self, "_rc_t_key", None) != t_ck:
            merged = _build_merged([target], ref_inv)
            if merged is None:
                print("[RibbonWrap] no polygon geometry found in target hierarchy")
                return c4d.BaseObject(c4d.Onull)
            rc_t = utils.GeRayCollider()
            if not rc_t.Init(merged):
                return c4d.BaseObject(c4d.Onull)
            self._rc_t = rc_t
            self._rc_t_key = t_ck
            self._rc_t_mesh = merged
            self._rc_polys = merged.GetPolygonCount()

        # wrap-over collider (separate cache: usually light, rebuilds when
        # the avoid objects move — e.g. dragged along with this parent)
        colliders = [self._rc_t]
        if avoid_roots:
            a_ck = (tuple(o.GetGUID() for o in avoid_roots), akey)
            if getattr(self, "_rc_a", None) is None or getattr(self, "_rc_a_key", None) != a_ck:
                amerged = _build_merged(avoid_roots, ref_inv)
                if amerged is not None:
                    rc_a = utils.GeRayCollider()
                    if rc_a.Init(amerged):
                        self._rc_a = rc_a
                        self._rc_a_key = a_ck
                        self._rc_a_mesh = amerged
                    else:
                        self._rc_a = None
                else:
                    self._rc_a = None
                    self._rc_a_key = a_ck
            if getattr(self, "_rc_a", None) is not None:
                colliders.append(self._rc_a)
        else:
            self._rc_a = None
            self._rc_a_key = None

        mg_n, _, _, _ = _normalized_mg(op.GetMg())
        samples = self._sample_wrap(op, colliders, mg_n, tmg)
        if samples is None:
            print("[RibbonWrap] no samples: check that the orange box "
                  "encloses the target (Radius/Length), and Start/End range. "
                  "merged polys=%d" % getattr(self, "_rc_polys", 0))
            return c4d.BaseObject(c4d.Onull)

        # geometry was computed in unit-scale (normalized) space; C4D will
        # apply the object's full (possibly scaled) matrix to this cache, so
        # pre-divide by the scale to keep Width/Offset/UV absolute
        # optional absolute ribbon length: trim samples at the given arc length
        riblen = max(0.0, _val(op, RW_RIBLEN, 0.0))
        if riblen > 0.001 and len(samples) >= 2:
            trimmed = [samples[0]]
            acc = 0.0
            for j in range(1, len(samples)):
                seg = (samples[j][0] - samples[j - 1][0]).GetLength()
                if acc + seg >= riblen:
                    f = (riblen - acc) / seg if seg > 1e-9 else 0.0
                    p = samples[j - 1][0] + (samples[j][0] - samples[j - 1][0]) * f
                    n = samples[j - 1][1] + (samples[j][1] - samples[j - 1][1]) * f
                    n.Normalize()
                    trimmed.append((p, n))
                    break
                acc += seg
                trimmed.append(samples[j])
            samples = trimmed
            if len(samples) < 2:
                return c4d.BaseObject(c4d.Onull)

        uv_opts = (_val(op, RW_UVROT, 0),
                   _val(op, RW_UVFLIPU, False),
                   _val(op, RW_UVFLIPV, False),
                   riblen)

        # self-overlap banking: when coil pitch < ribbon width, tilt the strip
        # so its trailing edge rides on the previous coil (like tape wrapping)
        bank = None
        width_v = max(0.001, _val(op, RW_WIDTH, 10.0))
        thick_v = max(0.0, _val(op, RW_THICK, 0.0))
        if _val(op, RW_OVERLAP, True) and thick_v > 0.0001:
            coils_v = max(0.01, _val(op, RW_COILS, 6.0))
            len_v = max(0.001, _val(op, RW_LENGTH, 200.0))
            pitch = len_v / coils_v
            if width_v > pitch:
                s_ax, _, _ = _axis_scales(_val(op, RW_AXIS, AXIS_Z), 1, 1, 1)
                u_a, v_a, w_a = _axis_basis(_val(op, RW_AXIS, AXIS_Z))
                travel = -1.0 if _val(op, RW_REV_DIR, False) else 1.0
                sinb = min(0.95, thick_v / width_v)
                bank = (w_a * travel, sinb)

        if _val(op, RW_OUTPUT, OUT_RIBBON) == OUT_SPLINE:
            out = self._build_spline(samples)
        else:
            out = self._build_ribbon(samples, width_v,
                                     _val(op, RW_TEXLEN, 0.0),
                                     uv_opts, thick_v, bank)
        mg_full = op.GetMg()
        mg_n2, _, _, _ = _normalized_mg(mg_full)
        conv = (~mg_full) * mg_n2
        if abs(conv.v1.GetLength() - 1.0) > 1e-9 or \
           abs(conv.v2.GetLength() - 1.0) > 1e-9 or \
           abs(conv.v3.GetLength() - 1.0) > 1e-9:
            out.SetAllPoints([conv * p for p in out.GetAllPoints()])
            out.Message(c4d.MSG_UPDATE)
        return out


if __name__ == "__main__":
    import os
    import threading
    print("[RibbonWrap] v%s loading from: %s" % (RW_VERSION, __file__))
    icon = c4d.bitmaps.BaseBitmap()
    icon_path = os.path.join(os.path.dirname(__file__), "res", "icon.png")
    if icon.InitWith(icon_path)[0] != c4d.IMAGERESULT_OK:
        icon = None
    c4d.plugins.RegisterObjectPlugin(
        id=PLUGIN_ID,
        str="RibbonWrap",
        g=RibbonWrapData,
        description="oribbonwrap",
        icon=icon,
        info=c4d.OBJECT_GENERATOR)
    c4d.plugins.RegisterCommandPlugin(
        id=PLUGIN_ID + 1,
        str="RibbonWrap: Check for Updates",
        info=0,
        icon=None,
        help="RibbonWrap 업데이트 확인",
        dat=RibbonWrapCheckCmd())
    threading.Thread(target=_check_update_bg, daemon=True).start()
