CONTAINER Oribbonwrap
{
    NAME oribbonwrap;
    INCLUDE Obase;

    GROUP ID_OBJECTPROPERTIES
    {
        LINK RW_TARGET { ACCEPT { Obase; } }

        LONG RW_AXIS
        {
            CYCLE
            {
                RW_AXIS_X;
                RW_AXIS_Y;
                RW_AXIS_Z;
            }
        }

        LONG RW_MODE
        {
            CYCLE
            {
                RW_MODE_CYL;
                RW_MODE_SPH;
            }
        }

        LONG RW_SHAPE
        {
            CYCLE
            {
                RW_SHAPE_ELLIPSE;
                RW_SHAPE_CAPSULE;
            }
        }

        BOOL RW_SHOWGUIDE { }

        REAL RW_LENGTH   { UNIT METER; MIN 0.001; STEP 1.0; }
        REAL RW_RADIUS   { UNIT METER; MIN 0.001; STEP 1.0; }
        REAL RW_RADIUS2  { UNIT METER; MIN 0.001; STEP 1.0; }
        REAL RW_RADSCALE { UNIT PERCENT; MIN 10.0; MAX 500.0; CUSTOMGUI REALSLIDER; STEP 1.0; }
        REAL RW_COILS    { MIN 0.1; MAX 200.0; STEP 0.5; }
        LONG RW_SEGMENTS { MIN 8; MAX 512; }
    }

    GROUP RW_GRP_RIBBON
    {
        REAL RW_WIDTH    { UNIT METER; MIN 0.001; STEP 0.5; }
        REAL RW_THICK    { UNIT METER; MIN 0.0; STEP 0.1; }
        BOOL RW_OVERLAP  { }
        REAL RW_OFFSET   { UNIT METER; STEP 0.1; }
        REAL RW_RIBLEN   { UNIT METER; MIN 0.0; STEP 5.0; }

        LONG RW_OUTPUT
        {
            CYCLE
            {
                RW_OUTPUT_RIBBON;
                RW_OUTPUT_SPLINE;
            }
        }
    }

    GROUP RW_GRP_FIT
    {
        BOOL RW_OUTER    { }
        LONG RW_TAUT     { MIN 0; MAX 500; }
        REAL RW_SAG      { UNIT METER; MIN 0.0; STEP 0.5; }
        LONG RW_SMOOTH_ITER { MIN 0; MAX 20; }
        BOOL RW_FLIP_NORMAL { }
        IN_EXCLUDE RW_AVOID { NUM_FLAGS 0; }
    }

    GROUP RW_GRP_WRAP
    {
        REAL RW_START { UNIT PERCENT; MIN 0.0; MAX 100.0; CUSTOMGUI REALSLIDER; STEP 1.0; }
        REAL RW_END   { UNIT PERCENT; MIN 0.0; MAX 100.0; CUSTOMGUI REALSLIDER; STEP 1.0; }
        REAL RW_TILT     { UNIT DEGREE; MIN -80.0; MAX 80.0; STEP 1.0; }
        BOOL RW_REV_DIR  { }
        BOOL RW_REV_SPIN { }
    }

    GROUP RW_GRP_UV
    {
        REAL RW_TEXLEN   { UNIT METER; MIN 0.0; STEP 1.0; }
        LONG RW_UVROT
        {
            CYCLE
            {
                RW_UVROT_0;
                RW_UVROT_90;
                RW_UVROT_180;
                RW_UVROT_270;
            }
        }
        BOOL RW_UVFLIPU  { }
        BOOL RW_UVFLIPV  { }
    }
}
