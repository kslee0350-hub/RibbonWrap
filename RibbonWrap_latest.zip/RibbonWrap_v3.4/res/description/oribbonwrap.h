#ifndef ORIBBONWRAP_H__
#define ORIBBONWRAP_H__

enum
{
    Oribbonwrap = 1063321,

    RW_GRP_RIBBON  = 2001,
    RW_GRP_FIT     = 2002,
    RW_GRP_WRAP    = 2003,
    RW_GRP_UV      = 2004,

    RW_TARGET      = 1000,
    RW_AXIS        = 1001,
        RW_AXIS_X = 0,
        RW_AXIS_Y = 1,
        RW_AXIS_Z = 2,
    RW_COILS       = 1002,
    RW_SEGMENTS    = 1003,
    RW_OFFSET      = 1004,
    RW_WIDTH       = 1005,
    RW_START       = 1006,
    RW_END         = 1007,
    RW_OUTPUT      = 1008,
        RW_OUTPUT_RIBBON = 0,
        RW_OUTPUT_SPLINE = 1,
    RW_FLIP_NORMAL = 1009,
    RW_SMOOTH_ITER = 1010,
    RW_LENGTH      = 1014,
    RW_RADIUS      = 1015,
    RW_TEXLEN      = 1016,
    RW_REV_DIR     = 1017,
    RW_REV_SPIN    = 1018,
    RW_OUTER       = 1019,
    RW_TAUT        = 1020,
    RW_SAG         = 1021,
    RW_TILT        = 1022,
    RW_UVROT       = 1023,
        RW_UVROT_0   = 0,
        RW_UVROT_90  = 1,
        RW_UVROT_180 = 2,
        RW_UVROT_270 = 3,
    RW_UVFLIPU     = 1024,
    RW_UVFLIPV     = 1025,
    RW_RIBLEN      = 1026,
    RW_THICK       = 1027,
    RW_RADIUS2     = 1028,
    RW_RADSCALE    = 1029,
    RW_SHAPE       = 1030,
        RW_SHAPE_ELLIPSE = 0,
        RW_SHAPE_CAPSULE = 1,
    RW_SHOWGUIDE   = 1031,
    RW_AVOID       = 1032,
    RW_OVERLAP     = 1033
};

#endif
