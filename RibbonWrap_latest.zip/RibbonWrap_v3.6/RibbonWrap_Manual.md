# RibbonWrap

**최신 버전: v3.6** · Cinema 4D 2026.x · [다운로드 (RibbonWrap_latest.zip)](https://github.com/kslee0350-hub/RibbonWrap/raw/main/RibbonWrap_latest.zip)

타겟 오브젝트 주위에 레이캐스트 방식으로 리본을 감아주는 C4D 제너레이터 플러그인. 표면 노멀 기반으로 리본 방향이 자동 정렬되어 Rail 스플라인 없이 표면에 밀착됩니다.

## v3.6 변경사항

- **업데이트 알림 다이얼로그 안정화**: C4D 시작 직후 알림 창이 뜨지 않던 문제 수정 (타이머 폴백 추가)

### 이전 버전 주요 기능

- v3.5 — 자식 오브젝트 자동 Wrap Over 인식 (계층 방식)
- v3.4 — 코일 겹침 자동 처리(Auto Layer Overlap), 리본 간 회피(Wrap Over Objects)
- v3.3 — Show Guide 체크박스
- v3.2 — Capsule(알약형) 단면
- v3.1 — 자동 업데이트 알림

---

## 설치

1. C4D 종료
2. 이전 버전 RibbonWrap 폴더가 있으면 **전부 삭제** (버전이 여러 개 있으면 ID 충돌로 구버전이 로드됨)
3. 압축 해제한 `RibbonWrap_vX.X` 폴더를 plugins 폴더에 복사
   - 예: `C:\Users\<사용자>\AppData\Roaming\Maxon\<C4D 버전>\plugins\`
4. C4D 실행 → Python 콘솔(Shift+F10)에 `[RibbonWrap] vX.X loading from: ...` 이 한 번 출력되면 정상 (버전은 설치본 기준)

## 빠른 시작

1. **Extensions > RibbonWrap** 생성
2. **Target** 링크에 감을 오브젝트를 드래그 (Null 계층/멀티 파트 메시 지원)
3. RibbonWrap 오브젝트를 이동·회전해 주황 가이드 박스가 감을 구간을 감싸게 배치
4. **Wrap Axis**를 타겟의 장축 방향과 맞춤
5. 핸들(주황 점 3개)로 박스 크기 조절 → Coils, Width 등 세부 조정

---

## 파라미터 — Object 탭

**Target**
감을 대상. 단일 메시, 파라메트릭 오브젝트, Null 아래 여러 파트로 구성된 계층 모두 가능. 게임 에셋처럼 파트가 많은 오브젝트는 내부적으로 병합되어 처리됩니다.
팁: 초고폴리 에셋은 저해상도 프록시를 타겟으로 쓰면 더 빠르고 결과도 깔끔합니다.

**Wrap Axis (X/Y/Z)**
감김이 진행되는 축 (플러그인 오브젝트의 로컬 축 기준). 하늘색 가이드 라인이 이 축을 표시합니다. 타겟의 긴 방향과 맞춰야 정상적으로 감깁니다.

**Length**
감김 구간의 축 방향 길이. 축 끝의 핸들로도 조절 가능.

**Radius Horizontal / Radius Vertical**
감김 단면(타원)의 가로/세로 반경. 레이가 이 타원 궤도에서 축을 향해 발사되므로, **타겟이 이 반경 안에 완전히 들어와야** 리본이 생성됩니다. 납작한 오브젝트(총기 등)는 두 값을 다르게 잡으면 레이 시작점이 표면에 가까워져 효율적입니다. 옆면 핸들 2개로 각각 드래그 조절 가능.

**Section Shape (Ellipse / Capsule)**
감김 단면의 모양.
- Ellipse: 타원 (기본)
- Capsule (Pill): 알약 단면 — 긴 축의 양 끝만 둥글고 중간은 평평한 직선 구간. 세로로 긴 오브젝트(스코프+탄창 달린 총기 측면 등)에 타원보다 균일하게 밀착됩니다. 레이가 경계의 안쪽 법선 방향으로 발사되어 평평한 구간은 수평으로 감깁니다. Radius H/V 중 긴 쪽에 평평한 구간이 생기고, 두 값이 같으면 원과 동일합니다. 뷰포트 가이드 양 끝에 단면 모양이 표시됩니다.

**Show Guide**
뷰포트의 주황 가이드 박스/단면/축 표시를 켜고 끕니다. 세팅이 끝나 렌더 프리뷰를 볼 때 끄면 화면이 깔끔합니다. 꺼도 선택 시 핸들은 표시됩니다.

**Radius Scale (Uniform)**
가로/세로 반경을 비율 유지한 채 한 번에 키우고 줄이는 통합 슬라이더 (10~500%). 타원 비율을 잡아둔 뒤 전체 크기만 맞출 때 사용.

**Coils**
감는 바퀴 수. 간격(피치) = Length ÷ Coils.

**Segments per Coil**
한 바퀴당 샘플(레이) 수. 낮으면 각지고 빠름, 높으면 부드럽고 느림. 보통 32~64. 미세 디테일이 많은 표면은 올리기.

## 파라미터 — Ribbon 탭

**Ribbon Width**
리본 폭 (cm 절대값). 오브젝트 스케일과 무관하게 유지됨.

**Thickness**
리본 두께. 0이면 납작한 단면 스트립, 값을 주면 윗면/아랫면/옆면/끝단 캡이 닫힌 솔리드 메시 생성. 권장: 폭의 5~10%. SSS/Transmission 재질에는 솔리드 필수.

**Auto Layer Overlap**
코일 간격(피치)이 리본 폭보다 좁아 코일끼리 겹칠 때, 실제 테이프 감기처럼 스트립을 기울여 뒤쪽 가장자리가 이전 코일 위로 올라타게 합니다 (Thickness > 0일 때만 동작, 들리는 높이 = Thickness). 붕대/테이핑 표현에 사용. 여러 겹이 쌓이는 극단적 겹침(폭이 피치의 2배 이상)은 한 겹 올라타는 것까지만 표현됩니다.

**Surface Offset**
표면에서 리본(아랫면)을 띄우는 거리. 리본이 표면을 파고들면 올리세요.

**Ribbon Length (0 = Fill Box)**
- 0: 박스 구간을 Coils만큼 채움
- 값 지정: 리본의 실제 누적 길이가 그 값(cm)에 도달하면 정확히 끝남. 이 모드에서는 텍스처가 리본 전체에 1회 매핑(U 0~1)됨 — 끝단 디자인이 있는 실물 리본 텍스처에 적합

**Output**
- Ribbon Mesh: UV·Phong 태그 포함 완성 메시 (기본)
- Spline: 스플라인만 출력 — Sweep 등 별도 지오메트리 파이프라인에 쓸 때

## 파라미터 — Surface Fit 탭

**Outer Hull Only (Taut Band)**
켜면 리본이 팽팽하게 당겨진 밴드처럼 동작: 구멍·틈·깊은 홈을 파고들지 않고 건너뜀. 총기처럼 돌출부와 빈 공간이 많은 오브젝트에 필수.

**Tautness Iterations**
당김 계산 반복 수. 80~150 권장. 낮으면 덜 당겨지고, 높으면 완전히 팽팽.

**Sag Depth**
팽팽한 외곽선에서 표면 쪽으로 가라앉을 수 있는 깊이(cm).
- 0 = 완전히 팽팽 (벙벙하게 뜸)
- 2~5 = 얕은 굴곡은 밀착, 깊은 틈만 건너뜀 (권장)
- 클수록 표면에 더 밀착

**Smoothing**
샘플 포지션/노멀 스무딩 반복. 표면 디테일에 리본이 지글거릴 때 올리기 (2~5).

**Flip Normals**
리본이 뒤집혀(안쪽을 향해) 보일 때 체크.

**Wrap Over Objects**
리본이 타고 넘어야 할 오브젝트를 지정하는 방법은 두 가지이며 함께 사용할 수 있습니다.
1. **계층 방식(권장)**: Object Manager에서 해당 오브젝트(다른 RibbonWrap 포함)를 이 RibbonWrap의 자식으로 넣으면 자동으로 인식됩니다.
2. **리스트 방식**: 여기에 등록한 오브젝트의 지오메트리가 충돌 대상에 추가됩니다. 다른 RibbonWrap을 등록하면 이 리본이 그 리본 위를 타고 넘어가서 서로 관통하지 않습니다. 임의 메시(스트랩, 부착물 등)도 등록 가능.
주의: 반드시 한 방향으로만 참조하세요 (B가 A를 넘어가게 했으면, A에는 B를 넣지 말 것 — 순환 참조는 무한 갱신을 유발합니다).

## 파라미터 — Wrap / Animation 탭

**Start / End (Growth)**
감김의 생성 구간 (0~100%). End에 키프레임을 주면 리본이 감아 올라가는 성장 애니메이션. Reverse Direction과 조합해 방향 제어.

**Coil Tilt (-80°~+80°)**
감김 축은 유지한 채 각 코일의 평면만 기울임 — 선물 포장처럼 사선으로 가로지르는 감김. 기울기 오프셋은 각 지점의 반경에 비례해 자연스럽게 적용됨. 박스 자체를 회전시키는 것과 달리 레이 방향이 유지되어 안정적.

**Reverse Direction**
감김 진행 방향 반전 (+축 시작 ↔ -축 시작).

**Reverse Spin (CW/CCW)**
회전 방향 반전 (시계 ↔ 반시계). 두 옵션 조합으로 4가지 감김 패턴 가능.

## 파라미터 — UV 탭

**Texture Tile Length**
타일 모드(Ribbon Length = 0)에서 텍스처 1회 반복에 해당하는 리본 실측 길이(cm). 예: 폭 10cm × 길이 50cm 비율로 디자인된 텍스처면 Width 10 / Tile Length 50. 리본이 굴곡을 따라 휘어도 실측 간격으로 왜곡 없이 반복됨. 0이면 폭×5로 자동 설정.

**UV Rotation (0°/90°/180°/270°)**
텍스처가 길이 방향이 아닌 폭 방향으로 흐르면 90°로 회전.

**UV Flip U / Flip V**
각 축 미러링.

Octane 팁: 반복 텍스처는 Image Texture의 Border mode를 Wrap around로. 모든 데이터 맵(노멀 등)은 평소처럼 Non-color/Gamma 1.0.

---

## 조작 요약

| 하고 싶은 것 | 방법 |
|---|---|
| 감김 위치 이동 | RibbonWrap 오브젝트 이동/회전 |
| 감김 구간 길이 | Length 또는 축 끝 핸들 |
| 감김 단면 크기 | Radius H/V, 옆면 핸들, 또는 Radius Scale |
| 감김 간격(피치) | Coils ↑ = 촘촘, Length ↑ = 성김 |
| 밀착도 | Sag Depth ↑ = 밀착, Outer Hull off = 완전 밀착(틈 파고듦) |
| 감아 올라가는 애니메이션 | End (Growth) 키프레임 |
| 결과 굳히기 | Current State to Object (UVW/Phong 태그 포함됨) |

## 문제 해결

**리본이 아예 안 생김**
- 주황 박스가 타겟을 감싸는지 확인 (타겟이 반경 밖이면 레이가 못 맞힘)
- End (Growth)가 0%가 아닌지
- Python 콘솔(Shift+F10)에서 `[RibbonWrap]` 진단 메시지 확인

**표면을 파고듦** → Outer Hull 켜기, Sag Depth 낮추기, Surface Offset 올리기

**너무 붕 뜸** → Sag Depth 올리기 (2~5부터), Tautness 낮추기

**리본이 지글거림** → Smoothing 올리기, 또는 저해상도 프록시를 타겟으로

**텍스처 방향이 이상함** → UV Rotation 90° 시도, 필요시 Flip U/V

**무겁고 느림** → Segments 낮추기, 프록시 메시 타겟 사용. 타겟 지오메트리는 캐싱되므로 박스 이동/파라미터 조절은 첫 계산 후 빨라짐

**태그가 안 보임** → 제너레이터 상태에서는 Object Manager에 태그가 표시되지 않음 (내부 캐시에 존재). 렌더에는 정상 적용되며, Current State to Object로 굳히면 보임

## 자동 업데이트 알림

플러그인은 C4D 시작 시 GitHub의 버전 정보를 확인해서, 새 버전이 있으면 알림 창을 띄우고 다운로드 페이지를 열어줍니다. 인터넷이 안 되거나 저장소가 없으면 조용히 넘어갑니다 (시작 속도에 영향 없음, 백그라운드 4초 타임아웃).

- 확인 주소: `raw.githubusercontent.com/kslee0350-hub/ribbonwrap/main/version.json`
- 최신 상태면 콘솔에 `[RibbonWrap] up to date` 출력

## 버전 기록

- v3.6 업데이트 알림 다이얼로그 안정화
- v3.5 자식 오브젝트 자동 Wrap Over 인식
- v3.4 Auto Layer Overlap (코일 겹침 뱅킹), Wrap Over Objects (리본 간 회피)
- v3.3 Show Guide 체크박스
- v3.2 Capsule 단면 (알약형), 단면 가이드 표시
- v3.1 GitHub 업데이트 알림
- v3.0 Radius Horizontal/Vertical 명칭, Radius Scale 통합 조절, 사용 설명서
- v2.9 Radius 가로/세로 분리 (타원 감김), 핸들 3개
- v2.8 콜라이더 캐시 keep-alive 수정
- v2.7 UI 탭 구성, 월드공간 콜라이더 캐싱 (다중 복사 최적화)
- v2.6 Thickness (솔리드 리본)
- v2.5 UV 회전/플립, Ribbon Length 모드
- v2.4 스케일 변경 시 리빌드 (CheckDirty), 핸들 확대
- v2.2~2.3 스케일-파라미터 분리, 드래그 핸들, 로드 배너
- v2.1 Coil Tilt, 스케일 베이킹
- v2.0 Sag Depth, 아이콘
- v1.9 Outer Hull (taut band)
- v1.5~1.8 2026 API 대응, 파라미터 안정화, 실측 UV
- v1.0~1.4 초기 구현 (헬릭스 레이캐스트, 축 잠금, 가이드 박스)
